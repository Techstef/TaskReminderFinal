# To-Do-List-and-Notes
A To Do List application made using python, kivy, kivymd, it has a multiple notification remainder on basis of priority, as well as notes, diary writer with password protection for notes.
This app helps you to keep track of your daily, weekly tasks in order to manage and optimize your time more efficiently. The app lets you to set notification remainder on basis of priority set by you, you can use it as a personal diary to write your daily notes and much more... To Do List & Notes come with built in password protection for your private notes.
Password protection of notes can be encrypted using fermet encryption, which has not been done yet.
Anyone can use these codes and modify
